package com.myspring.cookpro.recipeboard.dao;

public class RecipeDAOImpl {

}
