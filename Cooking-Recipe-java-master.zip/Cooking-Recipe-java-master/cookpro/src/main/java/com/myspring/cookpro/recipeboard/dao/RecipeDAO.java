package com.myspring.cookpro.recipeboard.dao;

public interface RecipeDAO {

}
