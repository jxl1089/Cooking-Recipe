package com.myspring.cookpro.recipeboard.service;

public class RecipeServiceImpl {

}
